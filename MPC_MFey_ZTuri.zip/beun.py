import numpy as np


A = np.ones([3, 2])
x = 2 * np.ones([1, 2])

print(A @ x)
